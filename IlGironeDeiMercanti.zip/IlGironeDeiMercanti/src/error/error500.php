<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error 500 - Internal Server Error</title>
    <link rel="stylesheet" href="../style.css">
</head>

<body>
    <h1>Error 500 - Internal Server Error</h1>
    <p>Sorry, something went wrong on the server.</p>
    </body>

</html>