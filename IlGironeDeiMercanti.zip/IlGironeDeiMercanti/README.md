# IlGironeDeiMercanti

witeboard: https://witeboard.com/5e618db0-0b9c-11ef-8f45-9d81b0051bda
draw.io: https://drive.google.com/file/d/1pK58VKcrAxa9XzGfp2u_8RisqvGT30mR/view?usp=sharing

create a database using phpmyadmin, call it "ilgirone", import ilgirone.sql file
