<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error 400 - Bad Request</title>
    <link rel="stylesheet" href="../style.css">
</head>

<body>
    <h1>Error 400 - Bad Request</h1>
    <p>
        Sorry, the request could not be understood by the server due to malformed syntax. The client should not repeat
        the request without modifications.
    </p>
</body>

</html>